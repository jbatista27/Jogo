<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            require_once 'Conexao.php';
            $con = new Conexao();
            $q = 10;
            $direcao = "horaria";
            $direcao2 = "antHorario";
            
            $m1 = "P1 na direção $direcao, P2 na direção $direcao2, P1 na Direção $direcao ";
            $sql = "INSERT INTO oi(mensage) VALUES(?);";
            $comando = $con->getCon()->prepare($sql);
            $comando->bindParam(1, $m1);
            $comando->execute();
            
            echo "$m1; ";
            for ($i = 1; $i < $q; $i++) {
                $valor = 3+$i;
                $valor2 = (3+$i)-1;
                
                $sql2 = "SELECT*FROM oi;";
                $comando2 = $con->getCon()->prepare($sql2);
                $comando2->execute();
                $obj2 = $comando2->fetch(PDO::FETCH_OBJ);
                $mensage2 = $obj2->mensage;
                               
                for ($j = $valor2; $j < $valor; $j++) {
                    $a = explode(",", $mensage2);
                    $ms = "P$j na direção $direcao";
                    array_push($a,$ms);
                    $resultado = implode(" , ", $a);
                    
                    $sql3 = "UPDATE oi SET mensage=?";
                    $comando3 = $con->getCon()->prepare($sql3);
                    $comando3->bindParam(1, $resultado);
                    $comando3->execute();
                                       
                }
               
                $sql4 = "SELECT*FROM oi;";
                $comando4 = $con->getCon()->prepare($sql4);
                $comando4->execute();
                $obj = $comando4->fetch(PDO::FETCH_OBJ);
                $mensage = $obj->mensage;
                echo "$mensage";
                echo "<br>";
                                                           
            }
        ?>
    </body>
</html>
